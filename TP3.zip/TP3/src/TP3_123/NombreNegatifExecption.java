package TP3_123;

/*Source : https://www.jmdoudoux.fr/java/dej/chap-exceptions.htm*/
public class NombreNegatifExecption extends Exception{

    //Execption si la valeur est negative
    public NombreNegatifExecption()
    {

    }
}
