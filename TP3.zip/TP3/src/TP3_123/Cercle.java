package TP3_123;

public class Cercle extends Forme{
    private double rayon;

    //Redefini la méthode de la classe Forme
    @Override
    public double getSurface(){
        return rayon*rayon*Math.PI;
    }

    //Par défaut
    public Cercle(){
        this.rayon=0;
        this.x=0;
        this.y=0;
    }

    //Second constructeur
    public Cercle(double rayon) {
        this.rayon = rayon;
        this.x=0;
        this.y=0;
    }

    //Troisième constrcuteur
    public Cercle(Cercle cercle)
    {
        this.rayon=cercle.rayon;
        this.x=0;
        this.y=0;
    }

    public Cercle(double rayon, double x, double y) {
        this.rayon = rayon;
        this.x=x;
        this.y=y;
    }

    @Override
    public String toString()
    {
        return "Le rayon du cercle est : "+ rayon+" Surface : "+ getSurface()+" X: "+x+" Y: "+y+"\n";
    }
}
