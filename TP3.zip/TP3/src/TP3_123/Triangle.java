package TP3_123;

public class Triangle extends Forme{
    private double base;
    private double hauteur;

    //Redefini la méthode de la classe Forme
    @Override
    public double getSurface(){
        return base*hauteur/2;
    }

    //Par défaut
    public Triangle(){
        this.base=0;
        this.hauteur=0;
        this.x=0;
        this.y=0;
    }

    //Second constructeur
    public Triangle(double base, double hauteur) {
        this.base = base;
        this.hauteur = hauteur;
        this.x=0;
        this.y=0;
    }

    //Troisième constrcuteur
    public Triangle (Triangle triangle)
    {
        this.base=triangle.base;
        this.hauteur=triangle.hauteur;
        this.x=0;
        this.y=0;
    }

    public Triangle (double base, double hauteur, double x, double y) {
        this.base = base;
        this.hauteur = hauteur;
        this.x=x;
        this.y=y;
    }

    @Override
    public String toString()
    {
        return "Le triangle a pour base : "+base+" et pour hauteur : "+hauteur+" Surface : "+ getSurface()+" X: "+x+" Y: "+y+"\n";
    }

}
