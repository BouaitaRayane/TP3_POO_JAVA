package TP3_123;

import java.text.Normalizer;
import java.util.Comparator;

public class comparatorSurface implements Comparator<Forme> {

    @Override
    public int compare(Forme forme1, Forme forme2) {
        if(forme1.getSurface() > forme2.getSurface()){return 1;}
        else if (forme1.getSurface() == forme2.getSurface()){return 0;}
        else {return -1;}
    }
}
