package TP3_123;

public class Carre extends Forme {
    private double longueur;

    //Redefini la méthode de la classe Forme
    @Override
    public double getSurface(){
        return longueur*longueur;
    }

    //Par défaut
    public Carre(){
        this.longueur=0;
        x=0;
        y=0;
    }

    //Second constructeur
    public Carre(double longueur) {
        this.longueur = longueur;
        this.x=0;
        this.y=0;

    }

    //Troisième constrcuteur
    public Carre (Carre carre)
    {
        this.longueur=carre.longueur;
        this.x=0;
        this.y=0;
    }

    public Carre(double longueur, double x, double y) {
        this.longueur = longueur;
        this.x=0;
        this.y=0;
    }

    @Override
    public String toString()
    {
        return "La longueur du carre est : "+ longueur+" Surface : "+ getSurface()+" X: "+x+" Y: "+y+"\n";
    }
}

