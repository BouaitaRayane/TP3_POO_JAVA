package TP3_123;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner clavier = new Scanner(System.in);
        int choix = 0;

        do {
            System.out.println("1: Question 3");
            System.out.println("2: Question 5");
            System.out.println("3: Question 6 et 7");
            System.out.println("4. Quitter");

            choix = clavier.nextInt();

            switch (choix) {
                case 1:
                    mainQuestion3();
                    break;
                case 2:
                    main1();
                    break;
                case 3:
                    mainfinal();
                    break;
                case 4:
                    System.out.println("Programme terminé");
                    break;
                default:
                    System.out.println("Veuillez saisir une option valide.");
            }
        } while (choix != 4);
    }






    public static void mainQuestion3 ()
    {
        //Initialisation avec le premier constructeur
        Carre carre1 = new Carre();
        Cercle cercle1 = new Cercle();
        Triangle triangle1 = new Triangle();

        Scanner clavier = new Scanner(System.in);

        //Bloc try
        try
        {
            System.out.println("      /*__CARRE__*/");
            //Saisie de la longueur
            System.out.print("Saisir la longueur du carre : ");
            double longueur=clavier.nextDouble();

            //Condition de l'exception
            if(longueur<=0)
            {
                //Arret de l'execution du bloc try, il y a une execption
                throw new NombreNegatifExecption();
            }

            //creation des deux nouveaux carré
            Carre carre2 = new Carre(longueur);
            Carre carre3 = new Carre(carre2);

            //affichage
            System.out.println("Carre 1 : "+ carre1.getSurface());
            System.out.println("Carre 2 : "+ carre2.getSurface());
            System.out.println("Carre 3 : "+ carre3.getSurface());
            System.out.println("Carre 1 : "+ carre1);
            System.out.println("Carre 2 : "+ carre2);
            System.out.println("Carre 3 : "+ carre3);
        }
        //Si une execption exsiste, alors on exectute la clause catch adéquate
        catch (NumberFormatException e1)
        {
            System.out.println("Saisir une valeure positive");
        }
        catch(NombreNegatifExecption e2)
        {
            System.out.println("Saisir une valeur strictement positive");
        }

        /*___________ON REPETE LE MEME PROCEDEE QUE PRECEDEMMENT_____________*/
        try
        {
            System.out.println("      /*__CERCLE__*/");
            System.out.print("Saisir le rayon du cercle: ");
            double rayon=clavier.nextDouble();

            if(rayon<=0)
            {
                throw new NombreNegatifExecption();
            }

            Cercle cercle2 = new Cercle(rayon);
            Cercle cercle3 = new Cercle(cercle2);

            System.out.println("Cercle 1 : "+ cercle1.getSurface());
            System.out.println("Cercle 2 : "+ cercle2.getSurface());
            System.out.println("Cercle 3 : "+ cercle3.getSurface());
            System.out.println("Cercle 1 : "+ cercle1);
            System.out.println("Cercle 2 : "+ cercle2);
            System.out.println("Cercle 3 : "+ cercle3);
        }
        catch (NumberFormatException e1)
        {
            System.out.println("Saisir une valeure positive");
        }
        catch(NombreNegatifExecption e2)
        {
            System.out.println("Saisir une valeur strictement positive");
        }


        try
        {
            System.out.println("   /*__TRIANGLE__*/");
            System.out.print("Saisir la hauteur du triangle : ");
            double hauteur=clavier.nextDouble();
            System.out.print("Saisir la base du triangle : ");
            double base=clavier.nextDouble();

            if(base<=0 || hauteur<=0)
            {
                throw new NombreNegatifExecption();
            }

            Triangle triangle2 = new Triangle(base, hauteur);
            Triangle triangle3 = new Triangle(triangle2);

            System.out.println("Triangle 1 : "+ triangle1.getSurface());
            System.out.println("Triangle 2 : "+ triangle2.getSurface());
            System.out.println("Triangle 3 : "+ triangle3.getSurface());
            System.out.println("Triangle 1 : "+ triangle1);
            System.out.println("Triangle 2 : "+ triangle2);
            System.out.println("Triangle 3 : "+ triangle3);
        }
        catch (NumberFormatException e1)
        {
            System.out.println("Saisir une valeure positive");
        }
        catch(NombreNegatifExecption e2)
        {
            System.out.println("Saisir une valeur strictement positive");
        }
    }

    public static void main1()
    {
        //Creation de la liste de forme
        ArrayList<Forme> liste = new ArrayList<>();
        Random alea = new Random();
        int indic=0;
        double LBRH, H;
        int nombreDeForme = alea.nextInt(14)+2;

        System.out.println("Taille : "+nombreDeForme);
        //Creation des données des formes
        for (int i =0; i<nombreDeForme; i++)
        {
            indic = alea.nextInt(3);
            //Creation carré
            if (indic == 0)
            {
                LBRH = alea.nextDouble()*10;
                liste.add(new Carre(LBRH));
            }
            //Création cercle
            else if (indic == 1)
            {
                LBRH = alea.nextDouble()*10;
                liste.add(new Cercle(LBRH));
            }
            //Création triangle
            else
            {
                LBRH = alea.nextDouble()*10;
                H = alea.nextDouble()*10;
                liste.add(new Triangle(LBRH,H));
            }
        }
        //Tri + affichage
        Collections.sort(liste);
        System.out.println(liste);



    }

    public static void mainfinal()
    {
        ArrayList<Forme> liste1 = new ArrayList<>();
        ArrayList<Forme> liste2 = new ArrayList<>();
        Random alea = new Random();
        Random x = new Random();
        Random y = new Random();
        int indic=0;
        double LBRH, H;
        int nombreDeForme = alea.nextInt(14)+2;

        System.out.println("Taille : "+nombreDeForme);
        //Creation des données des formes
        for (int i =0; i<nombreDeForme; i++)
        {
            indic = alea.nextInt(3);
            //Creation carré
            if (indic == 0)
            {
                LBRH = alea.nextDouble()*10;
                liste1.add(new Carre(LBRH));
                liste2.add(new Carre(LBRH,(x.nextInt(21)-10),(y.nextInt(21)-10)));

            }
            //Création cercle
            else if (indic == 1)
            {
                LBRH = alea.nextDouble()*10;
                liste1.add(new Cercle(LBRH));
                liste2.add(new Cercle(LBRH,(x.nextInt(21)-10),(y.nextInt(21)-10)));
            }
            //Création triangle
            else
            {
                LBRH = alea.nextDouble()*10;
                H = alea.nextDouble()*10;
                liste1.add(new Triangle(LBRH,H));
                liste2.add(new Triangle(LBRH,H,(x.nextInt(21)-10),(y.nextInt(21)-10)));
            }
        }

        comparatorSurface c1 = new comparatorSurface();
        comparatorDistance c2 = new comparatorDistance();

        Collections.sort(liste1, c1);
        Collections.sort(liste2, c2);

        System.out.println("Tri selon La surface avec comparator : ");
        System.out.println(liste1);
        System.out.println("Tri selon la distane à l'origine avec comparator : ");
        System.out.println(liste2);

        ///AFFICHAGE FORME LA PLUS LOIN DE 0.0 et PLUS GRANDE SURFACE
        System.out.println("Plus grande surface : "+(liste1.get(liste1.size()-1)).toString());
        System.out.println("Plus grande distance a l'origine : "+(liste2.get(liste1.size()-1)).toString());

    }
}