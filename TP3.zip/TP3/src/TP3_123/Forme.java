package TP3_123;

public abstract class Forme implements Comparable<Forme> {

    //Coordonnées
    protected double x;
    protected double y;



    public abstract double getSurface();

    @Override
    public int compareTo(Forme otherForme) {
        if(this.getSurface()==otherForme.getSurface()){return 0;}
        else if (this.getSurface()>otherForme.getSurface()){return 1;}
        else {return -1;}

    }

    public double distanceorigine()
    {
        return Math.sqrt(x*x + y*y);
    }
}
