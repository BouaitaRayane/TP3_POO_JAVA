package TP3_123;

import java.util.Comparator;

public class comparatorDistance implements Comparator<Forme> {


        @Override
        public int compare(Forme forme1, Forme forme2) {
            if(forme1.distanceorigine() > forme2.distanceorigine()){return 1;}
            else if (forme1.distanceorigine() == forme2.distanceorigine()){return 0;}
            else {return -1;}
        }
    }

